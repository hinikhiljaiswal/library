import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Library Seat Booking',
  description: 'Book self-study center seats with Stripe payments.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
