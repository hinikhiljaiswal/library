import { Seat } from './seat.types';

const blocks = [
  { block: 'A', startColumn: 1, price: 149 },
  { block: 'B', startColumn: 2, price: 149 },
  { block: 'C', startColumn: 3, price: 199 },
  { block: 'D', startColumn: 1, price: 129 },
  { block: 'E', startColumn: 2, price: 129 },
  { block: 'F', startColumn: 3, price: 179 },
];

export const SEATS: Seat[] = blocks.flatMap(({ block, startColumn, price }, blockIndex) => {
  const rowOffset = blockIndex < 3 ? 1 : 6;

  return Array.from({ length: 4 }, (_, index) => ({
    id: `${block}${index + 1}`,
    row: rowOffset + index,
    column: startColumn,
    block,
    price,
  }));
});
